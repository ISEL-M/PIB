%
% ISEL - Instituto Superior de Engenharia de Lisboa.
%
% MEIC - Mestrado em Engenharia Informatica e de Computadores.
% MEIM - Mestrado em Engenharia Inform�tica e Multim�dia.
%
% PIB - Processamento de Imagem e Biometria.
%
% image_median_filter.m
% Fun��o que ilustra a aplica��o de opera��es sobre imagens com n�veis de cinzento.
% Compara��o do uso do filtro de m�dia com o filtro de mediana.

function image_median_filter()

% Fechar todas as janelas de figuras.
close all;

% Limpar a consola.
clc
I   = imread('eight.tif');
In  = imnoise(I,'salt & pepper',0.05);
%In = imnoise(I,'gaussian',0.02);

% Filtro de m�dia de 3x3
L = 3;
k1 = (1/L^2) * ones(L,L);
I_mean = filter2(k1, In);

% Filtro de mediana numa janela de 3x3
% B = medfilt2(A) performs median filtering 
% of the matrix A using the default 3-by-3 neighborhood.
I_median = medfilt2(In);

figure(1);
subplot(221); imshow(I);             title('Original');
subplot(222); imshow(In);            title('With noise (salt & pepper)');
subplot(223); imshow(uint8(I_mean)); title('Average (mean) (3x3)');
subplot(224); imshow(I_median);      title('Median (3x3)');
 
end



